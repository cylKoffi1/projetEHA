<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Motifs_changerchefprojet extends Model
{
    use HasFactory;
    protected $table = 'motifs_changerchefprojet';
    public $timestamps = false;
    
}
