<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TypeMateriauxConduite extends Model
{
    use HasFactory;
    public $timestamps = false;

    protected $table = 'type_materiaux_conduite'; // Nom de la table
    protected $keyType = 'string';
    protected $primaryKey = 'code';
    protected $fillable = ['code', 'libelle'];

}
